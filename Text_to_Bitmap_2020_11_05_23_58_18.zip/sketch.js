let font;
let points;
let bounds;
//Function to load Fonts
function preload()
{
  font = loadFont('BigCaslon.otf');
}
function setup()
{
  createCanvas(250, 300);
  imagesetup();
  sliders();
  buttonsetup();
}
function draw() 
{
  background(365);
  imagedraw();
  texts();
}
//Function to setup Button
function buttonsetup()
{
  button = createButton('Take Image');
  button.position(150, 200);
  button.mousePressed(takeimage);
}
//Function to take image of canvas
function takeimage()
{
 saveCanvas( 'Blake.Text_To_Image', 'jpg') 
}
//Function for writing all required text
function texts()
{
  R=rslider.value();
  G=gslider.value();
  B=bslider.value();
  textSize(20);
  fill(0,0,0);
  text('R value:', 0,-230)
  text('G value:', 0,-210)
  text('B value:', 0,-190)
  text('Text: ',0,-150)
  text('Bitmapped: ',0,-50)
  textSize(55);
  textFont('BigCaslon')
  fill(R,G,B);
  text('Hello',0,-100);
}
//Function for displaying sliders R,G,B
function sliders()
{
  rslider = createSlider(0, 365, 0)
  rslider.position(80, 20)
  gslider = createSlider(0, 365,0)
  gslider.position(80,40)
  bslider = createSlider(0, 365,0)
  bslider.position(80,60)
}
//Function for setting up Image
function imagesetup()
{
  points = font.textToPoints('Hello', 0, 0, 10, {
    sampleFactor: 5,
    simplifyThreshold: 0
  });
  bounds = font.textBounds(' Hello ', 0, 0, 30);
}
//Funstion for Drawing Image
function imagedraw()
{
  beginShape();
  stroke(0);
  translate(0, 260);
  for (let i = 0; i < 734; i++) {
    let p = points[i];
    vertex(
      p.x * 5,
      p.y * 5);
  }
  endShape(CLOSE);
}
